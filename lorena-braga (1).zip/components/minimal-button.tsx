"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import type { ReactNode } from "react"

interface MinimalButtonProps {
  children: ReactNode
  href: string
  className?: string
  delay?: number
}

export function MinimalButton({ children, href, className = "", delay = 0 }: MinimalButtonProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
    >
      <Link
        href={href}
        className={`minimal-button inline-block py-2 px-4 text-primary hover:text-primary/80 transition-colors duration-300 ${className}`}
      >
        {children}
      </Link>
    </motion.div>
  )
}
