"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface MinimalTextProps {
  children: ReactNode
  className?: string
  delay?: number
  tag?: "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "p" | "span"
}

export function MinimalText({ children, className = "", delay = 0, tag = "p" }: MinimalTextProps) {
  const Component = motion[tag as keyof typeof motion] || motion.p

  return (
    <Component
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      className={className}
    >
      {children}
    </Component>
  )
}
