"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface AnimatedTextProps {
  children: ReactNode
  className?: string
  delay?: number
  tag?: "p" | "span" | "h3" | "h4" | "li"
}

export function AnimatedText({ children, className = "", delay = 0, tag = "p" }: AnimatedTextProps) {
  const Component = motion[tag as keyof typeof motion] || motion.p

  return (
    <Component
      initial={{ opacity: 0, y: 10 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className={className}
    >
      {children}
    </Component>
  )
}
