"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface MinimalSectionProps {
  children: ReactNode
  className?: string
  delay?: number
  id?: string
}

export function MinimalSection({ children, className = "", delay = 0, id }: MinimalSectionProps) {
  return (
    <motion.section
      id={id}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 1, delay }}
      className={`py-24 md:py-32 ${className}`}
    >
      {children}
    </motion.section>
  )
}
