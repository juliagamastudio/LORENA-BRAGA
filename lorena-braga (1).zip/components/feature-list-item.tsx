"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface FeatureListItemProps {
  children: ReactNode
  delay?: number
}

export function FeatureListItem({ children, delay = 0 }: FeatureListItemProps) {
  return (
    <motion.li
      initial={{ opacity: 0, x: -10 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay }}
      className="flex items-start gap-3 mb-3"
    >
      <span className="text-current mt-1">
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="18"
          height="18"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z" />
          <path d="m9 12 2 2 4-4" />
        </svg>
      </span>
      <span>{children}</span>
    </motion.li>
  )
}
