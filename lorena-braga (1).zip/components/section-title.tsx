"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface SectionTitleProps {
  children: ReactNode
  className?: string
  delay?: number
}

export function SectionTitle({ children, className = "", delay = 0 }: SectionTitleProps) {
  return (
    <motion.h2
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8, delay }}
      className={`font-playfair font-medium italic text-4xl md:text-5xl text-[#43645d] tracking-tighter mb-8 ${className}`}
    >
      {children}
    </motion.h2>
  )
}
