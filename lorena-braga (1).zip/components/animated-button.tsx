"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import type { ReactNode } from "react"

interface AnimatedButtonProps {
  children: ReactNode
  className?: string
  href: string
}

export function AnimatedButton({ children, className = "", href }: AnimatedButtonProps) {
  return (
    <motion.div whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}>
      <Link
        href={href}
        className={`inline-block px-8 py-3 text-white transition-colors duration-300 gradient-bg ${className}`}
      >
        {children}
      </Link>
    </motion.div>
  )
}
