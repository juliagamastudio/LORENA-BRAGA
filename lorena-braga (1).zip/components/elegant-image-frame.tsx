"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface ElegantImageFrameProps {
  src: string
  alt: string
  className?: string
  delay?: number
  priority?: boolean
  variant?: "light" | "dark"
  aspectRatio?: string
}

export function ElegantImageFrame({
  src,
  alt,
  className,
  delay = 0,
  priority = false,
  variant = "light",
  aspectRatio = "4/5",
}: ElegantImageFrameProps) {
  const borderColor = variant === "light" ? "border-[#43645d]/20" : "border-white/20"
  const shadowColor = variant === "light" ? "shadow-[#43645d]/10" : "shadow-black/20"

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 1, delay }}
      className={cn(
        "relative p-3 bg-white/5 backdrop-blur-sm border rounded-lg overflow-hidden",
        borderColor,
        `shadow-lg ${shadowColor}`,
        className,
      )}
    >
      <div className={`relative w-full overflow-hidden rounded-md`} style={{ aspectRatio }}>
        <Image
          src={src || "/placeholder.svg"}
          alt={alt}
          fill
          priority={priority}
          className="object-cover transition-all duration-500 hover:scale-105"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
      </div>
    </motion.div>
  )
}
