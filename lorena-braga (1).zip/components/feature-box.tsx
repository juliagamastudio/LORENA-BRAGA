"use client"

import { motion } from "framer-motion"
import type { ReactNode } from "react"

interface FeatureBoxProps {
  children: ReactNode
  className?: string
  delay?: number
  icon?: ReactNode
}

export function FeatureBox({ children, className = "", delay = 0, icon }: FeatureBoxProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className={`box-highlight ${className}`}
    >
      {icon && <div className="mb-4 flex justify-center md:justify-start">{icon}</div>}
      {children}
    </motion.div>
  )
}
