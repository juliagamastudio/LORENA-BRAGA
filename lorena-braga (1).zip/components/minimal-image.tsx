"use client"

import { motion } from "framer-motion"
import Image from "next/image"

interface MinimalImageProps {
  src: string
  alt: string
  width?: number
  height?: number
  className?: string
  delay?: number
  priority?: boolean
}

export function MinimalImage({
  src,
  alt,
  width,
  height,
  className = "",
  delay = 0,
  priority = false,
}: MinimalImageProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 1.2, delay }}
      className={`relative overflow-hidden ${className}`}
    >
      <Image
        src={src || "/placeholder.svg"}
        alt={alt}
        width={width}
        height={height}
        priority={priority}
        className="object-cover w-full h-full"
      />
    </motion.div>
  )
}
