"use client"
import Image from "next/image"
import { motion } from "framer-motion"
import { useIntersectionObserver } from "@/hooks/use-intersection-observer"
import { cn } from "@/lib/utils"
import { useState } from "react"

interface EnhancedAnimatedImageProps {
  src: string
  alt: string
  width?: number
  height?: number
  fill?: boolean
  className?: string
  delay?: number
  priority?: boolean
  hoverEffect?: "zoom" | "glow" | "lift" | "fade" | "none"
}

export function EnhancedAnimatedImage({
  src,
  alt,
  width,
  height,
  fill = false,
  className,
  delay = 0,
  priority = false,
  hoverEffect = "none",
}: EnhancedAnimatedImageProps) {
  const [isVisible, ref] = useIntersectionObserver()
  const [isHovered, setIsHovered] = useState(false)

  const getHoverAnimation = () => {
    switch (hoverEffect) {
      case "zoom":
        return {
          scale: isHovered ? 1.05 : 1,
          transition: { duration: 0.4 },
        }
      case "glow":
        return {
          boxShadow: isHovered ? "0 0 20px rgba(67, 100, 93, 0.5)" : "0 0 0px rgba(67, 100, 93, 0)",
          transition: { duration: 0.4 },
        }
      case "lift":
        return {
          y: isHovered ? -10 : 0,
          transition: { duration: 0.4 },
        }
      case "fade":
        return {
          opacity: isHovered ? 0.8 : 1,
          transition: { duration: 0.4 },
        }
      default:
        return {}
    }
  }

  return (
    <div
      ref={ref}
      className={cn("relative overflow-hidden", className)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <motion.div
        initial={{ opacity: 0, scale: 1.05 }}
        animate={
          isVisible
            ? {
                opacity: 1,
                scale: 1,
                ...getHoverAnimation(),
              }
            : {
                opacity: 0,
                scale: 1.05,
              }
        }
        transition={{ duration: 0.8, delay, ease: "easeOut" }}
        className="h-full w-full"
      >
        <Image
          src={src || "/placeholder.svg"}
          alt={alt}
          width={width}
          height={height}
          fill={fill}
          priority={priority}
          className={cn("object-cover transition-all duration-500", className)}
        />
      </motion.div>
    </div>
  )
}
