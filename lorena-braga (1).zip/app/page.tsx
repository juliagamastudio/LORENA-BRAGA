"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { AnimatedButton } from "@/components/animated-button"
import { SectionTitle } from "@/components/section-title"
import { AnimatedText } from "@/components/animated-text"
import { FeatureBox } from "@/components/feature-box"
import { FeatureListItem } from "@/components/feature-list-item"
import { ElegantImageFrame } from "@/components/elegant-image-frame"

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    setLoaded(true)
  }, [])

  const sections = [
    "inicio",
    "porque-buscar",
    "como-ajuda",
    "para-quem",
    "porque-escolher",
    "quanto-custa",
    "agende",
    "fundadora",
  ]

  const handleScroll = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setMenuOpen(false)
  }

  return (
    <div className="relative">
      {/* Fixed Navigation */}
      <div className="fixed top-10 left-10 z-50">
        <div
          className="w-auto px-4 h-16 rounded-full bg-[#eeebe6] flex items-center justify-center cursor-pointer"
          onClick={() => handleScroll("inicio")}
        >
          <div className="text-[#43645d] font-playfair font-medium italic text-sm md:text-base">
            Lorena Braga | Psicóloga
          </div>
        </div>
      </div>

      <div className="fixed top-10 right-10 z-50">
        <div
          className="w-12 h-12 flex flex-col justify-center items-center gap-1.5 cursor-pointer"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <motion.div className="w-8 h-0.5 bg-[#43645d]" animate={{ rotate: menuOpen ? 45 : 0, y: menuOpen ? 6 : 0 }} />
          <motion.div className="w-8 h-0.5 bg-[#43645d]" animate={{ opacity: menuOpen ? 0 : 1 }} />
          <motion.div
            className="w-8 h-0.5 bg-[#43645d]"
            animate={{ rotate: menuOpen ? -45 : 0, y: menuOpen ? -6 : 0 }}
          />
        </div>
      </div>

      {/* Full Screen Menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            className="fixed inset-0 bg-[#eeebe6] z-40 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="text-center">
              <ul className="space-y-8">
                {[
                  { id: "inicio", label: "Início" },
                  { id: "porque-buscar", label: "Por que buscar ajuda?" },
                  { id: "como-ajuda", label: "Como a terapia ajuda" },
                  { id: "para-quem", label: "Para quem é" },
                  { id: "porque-escolher", label: "Por que nos escolher" },
                  { id: "quanto-custa", label: "Quanto custa" },
                  { id: "agende", label: "Agende sua sessão" },
                  { id: "fundadora", label: "Nossa fundadora" },
                ].map((item, index) => (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 * index }}
                    className="font-playfair font-medium italic text-2xl text-[#43645d] cursor-pointer hover:text-[#5395a0] transition-colors"
                    onClick={() => handleScroll(item.id)}
                  >
                    {item.label}
                  </motion.li>
                ))}
              </ul>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div>
        {/* Sessão 1: Bem-vinda */}
        <section
          id="inicio"
          className="min-h-screen w-full flex items-center justify-center bg-[#eeebe6] relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 1 }}
                className="max-w-xl"
              >
                <h1 className="font-playfair font-medium italic text-5xl md:text-6xl lg:text-7xl text-[#43645d] tracking-tighter mb-8">
                  Bem-vinda
                </h1>
                <p className="text-xl text-[#43645d]/80 mb-8">
                  Se você chegou até aqui, talvez esteja cansada de parecer forte o tempo todo. Talvez sinta que ficou
                  para trás ou que sua história não tem lugar. Aqui, você encontra acolhimento sem julgamento. Um espaço
                  para se reconectar com quem você é — sem precisar se encaixar em papéis que não viveu. Vamos juntas?
                </p>
                <div className="mt-12">
                  <AnimatedButton href="https://wa.link/mroli5" className="text-lg">
                    Agende sua sessão
                  </AnimatedButton>
                </div>
              </motion.div>
              <div className="hidden md:block">
                <ElegantImageFrame
                  src="https://i.imgur.com/GODPVad.jpeg"
                  alt="Psicóloga Lorena Braga"
                  priority
                  delay={0.3}
                  variant="light"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Sessão 2: Por que buscar ajuda? */}
        <section
          id="porque-buscar"
          className="min-h-screen w-full flex items-center bg-[#284146] text-white relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto">
              <SectionTitle className="text-white">Por que buscar ajuda?</SectionTitle>
              <AnimatedText className="text-lg mb-8 text-white/90">
                Você se cobra, se compara e sente que está sempre devendo algo. Mesmo tendo conquistado muita coisa,
                carrega o peso do que não viveu — e se pergunta se ainda dá tempo. Essa dor, por mais silenciosa que
                seja, precisa ser escutada. A terapia te ajuda a sair do automático e se reconectar com o que é seu.
              </AnimatedText>

              <AnimatedText className="text-xl mb-6 text-white/90" delay={0.2}>
                Talvez você se reconheça aqui:
              </AnimatedText>

              <ul className="space-y-4 mb-12">
                <FeatureListItem delay={0.3}>Culpa por não ter seguido o que esperavam</FeatureListItem>
                <FeatureListItem delay={0.4}>Comparação com quem parece estar "à frente"</FeatureListItem>
                <FeatureListItem delay={0.5}>Medo de ser vista como incompleta</FeatureListItem>
                <FeatureListItem delay={0.6}>Autocrítica que não dá trégua</FeatureListItem>
                <FeatureListItem delay={0.7}>Sensação de estar sozinha, mesmo acompanhada</FeatureListItem>
              </ul>

              <AnimatedText className="text-xl text-white/90 italic" delay={0.8}>
                Você não precisa seguir fingindo força. Aqui, você pode respirar e ser de verdade.
              </AnimatedText>
            </div>
          </div>
        </section>

        {/* Sessão 3: Como a terapia pode te ajudar? */}
        <section
          id="como-ajuda"
          className="min-h-screen w-full flex items-center bg-[#eeebe6] relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <SectionTitle>Como a terapia pode te ajudar?</SectionTitle>
              <AnimatedText className="text-lg mb-8 text-[#43645d]/80">
                A terapia é um espaço para se escutar de verdade. Um caminho para sair da autopunição, acolher o que não
                foi vivido e reencontrar sentido fora dos papéis impostos.
              </AnimatedText>

              <AnimatedText className="text-xl mb-6 text-[#43645d]" delay={0.2}>
                Aqui, você vai poder:
              </AnimatedText>

              <div className="grid md:grid-cols-2 gap-6 mb-12">
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                  className="gradient-box"
                >
                  <p className="text-white">Se reconectar com sua identidade</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                  className="gradient-box"
                >
                  <p className="text-white">Acolher suas dores sem julgamento</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.5 }}
                  className="gradient-box"
                >
                  <p className="text-white">Romper com a autocobrança e o perfeccionismo</p>
                </motion.div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                  className="gradient-box"
                >
                  <p className="text-white">Redefinir seus vínculos a partir do que é real para você</p>
                </motion.div>
              </div>

              <AnimatedText className="text-xl text-[#43645d] italic" delay={0.7}>
                É possível viver com mais leveza. E você não precisa fazer isso sozinha.
              </AnimatedText>
            </div>
          </div>
        </section>

        {/* Sessão 4: Para quem é esse espaço? */}
        <section
          id="para-quem"
          className="min-h-screen w-full flex items-center gradient-bg-section text-white relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto">
              <SectionTitle className="text-white">Para quem é esse espaço?</SectionTitle>
              <AnimatedText className="text-xl mb-6 text-white/90">Esse espaço é para mulheres que…</AnimatedText>

              <div className="grid md:grid-cols-2 gap-6 mb-12">
                <FeatureBox delay={0.3} className="bg-white/5 border-white/20">
                  <AnimatedText className="text-white/90">
                    Sentem que deram conta de tudo, mas ainda assim carregam um vazio.
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox delay={0.4} className="bg-white/5 border-white/20">
                  <AnimatedText className="text-white/90">
                    Não se tornaram mães ou esposas e se questionam por isso.
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox delay={0.5} className="bg-white/5 border-white/20">
                  <AnimatedText className="text-white/90">
                    Se cobram por não terem seguido os caminhos que "todas seguem".
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox delay={0.6} className="bg-white/5 border-white/20">
                  <AnimatedText className="text-white/90">
                    Vivem em silêncio o medo de envelhecer sem vínculos afetivos.
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox delay={0.7} className="bg-white/5 border-white/20">
                  <AnimatedText className="text-white/90">
                    Desejam reconstruir sua autoestima sem depender de aprovação.
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox delay={0.8} className="bg-white/5 border-white/20">
                  <AnimatedText className="text-white/90">
                    Estão cansadas de parecer bem e querem, de fato, se sentir bem.
                  </AnimatedText>
                </FeatureBox>
              </div>

              <AnimatedText className="text-xl text-white/90 italic text-center" delay={0.9}>
                Se você sente que se perdeu de si para tentar caber em papéis que não viveu… aqui você pode parar.
                Respirar. Recomeçar.
              </AnimatedText>
            </div>
          </div>
        </section>

        {/* Sessão 5: Por que escolher a nossa clínica? */}
        <section
          id="porque-escolher"
          className="min-h-screen w-full flex items-center bg-[#eeebe6] relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div className="hidden md:block">
                <ElegantImageFrame
                  src="https://i.imgur.com/jjfwMye.jpeg"
                  alt="Psicóloga Lorena Braga em sessão"
                  delay={0.3}
                  variant="light"
                />
              </div>
              <div>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8 }}
                  className="flex justify-center mb-8"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="40"
                    height="40"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#43645d]"
                  >
                    <path d="M19.5 12.572 12 17l-7.5-4.428V7.572L12 3l7.5 4.572v5" />
                    <path d="M12 17v4" />
                    <path d="M5 10.5 12 14l7-3.5" />
                  </svg>
                </motion.div>
                <SectionTitle>Por que escolher a nossa clínica?</SectionTitle>

                <ul className="space-y-4 mb-12">
                  <FeatureListItem delay={0.3}>Psicóloga com escuta sensível e sem fórmulas prontas</FeatureListItem>
                  <FeatureListItem delay={0.4}>Atendimento online, ético e acolhedor</FeatureListItem>
                  <FeatureListItem delay={0.5}>Especialista em saúde emocional feminina</FeatureListItem>
                  <FeatureListItem delay={0.6}>
                    Olhar profundo sobre a dor de não corresponder às expectativas sociais
                  </FeatureListItem>
                  <FeatureListItem delay={0.7}>
                    Um processo que respeita o seu tempo, sua história e sua singularidade
                  </FeatureListItem>
                </ul>

                <AnimatedText className="text-xl text-[#43645d] italic" delay={0.8}>
                  Você será acolhida com verdade — e guiada com presença.
                </AnimatedText>
              </div>
            </div>
          </div>
        </section>

        {/* Sessão 6: QUANTO CUSTA A TERAPIA? */}
        <section
          id="quanto-custa"
          className="min-h-screen w-full flex items-center bg-[#284146] text-white relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto">
              <SectionTitle className="text-white text-center">QUANTO CUSTA A TERAPIA?</SectionTitle>
              <AnimatedText className="text-lg mb-12 text-white/90 text-center">
                Investir na sua saúde emocional é o primeiro passo para mudar sua história. O valor por sessão
                individual é de R$ 270. Se fizer sentido pra você, será um cuidado construído com presença, profundidade
                e respeito pela sua trajetória.
              </AnimatedText>

              <div className="grid md:grid-cols-2 gap-8 mb-12">
                <FeatureBox
                  delay={0.3}
                  className="bg-white/5 border-white/20"
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-white/80"
                    >
                      <circle cx="12" cy="12" r="10" />
                      <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                      <path d="M12 17h.01" />
                    </svg>
                  }
                >
                  <AnimatedText tag="h3" className="text-xl text-white mb-3">
                    Resolução de dúvidas
                  </AnimatedText>
                  <AnimatedText className="text-white/90">
                    Antes de agendar a primeira sessão, você pode ter algumas dúvidas sobre o processo terapêutico.
                    Nossos atendentes estão disponíveis para responder a todas as suas perguntas e esclarecer quaisquer
                    preocupações que você possa ter.
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox
                  delay={0.4}
                  className="bg-white/5 border-white/20"
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-white/80"
                    >
                      <path d="M2 12h10" />
                      <path d="M9 4v16" />
                      <path d="M14 9l3 3-3 3" />
                      <path d="M17 6v12" />
                      <path d="M22 12h-5" />
                    </svg>
                  }
                >
                  <AnimatedText tag="h3" className="text-xl text-white mb-3">
                    Identificação do maior desafio
                  </AnimatedText>
                  <AnimatedText className="text-white/90">
                    Durante o processo de agendamento, é importante que você compartilhe qual é o seu maior desafio
                    atualmente. Isso nos ajuda a direcionar melhor o atendimento e identificar o profissional mais
                    adequado para acompanhar você.
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox
                  delay={0.5}
                  className="bg-white/5 border-white/20"
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-white/80"
                    >
                      <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
                      <line x1="16" x2="16" y1="2" y2="6" />
                      <line x1="8" x2="8" y1="2" y2="6" />
                      <line x1="3" x2="21" y1="10" y2="10" />
                      <path d="M8 14h.01" />
                      <path d="M12 14h.01" />
                      <path d="M16 14h.01" />
                      <path d="M8 18h.01" />
                      <path d="M12 18h.01" />
                      <path d="M16 18h.01" />
                    </svg>
                  }
                >
                  <AnimatedText tag="h3" className="text-xl text-white mb-3">
                    Definição da data e horário
                  </AnimatedText>
                  <AnimatedText className="text-white/90">
                    Depois de resolver suas dúvidas e compartilhar suas preocupações, é hora de definir uma data e
                    horário que funcione para você. Nós oferecemos opções flexíveis de agendamento para atender às suas
                    necessidades.
                  </AnimatedText>
                </FeatureBox>
                <FeatureBox
                  delay={0.6}
                  className="bg-white/5 border-white/20"
                  icon={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-white/80"
                    >
                      <rect width="20" height="14" x="2" y="5" rx="2" />
                      <line x1="2" x2="22" y1="10" y2="10" />
                    </svg>
                  }
                >
                  <AnimatedText tag="h3" className="text-xl text-white mb-3">
                    Valor da sessão
                  </AnimatedText>
                  <AnimatedText className="text-white/90">
                    O valor da sessão é R$270,00. Também oferecemos a possibilidade de um acompanhamento contínuo. Caso
                    deseje agendar 4 sessões de uma vez, os valores podem ser combinados diretamente. Aceitamos
                    pagamentos via PIX, boleto ou cartão, com total praticidade.
                  </AnimatedText>
                </FeatureBox>
              </div>
            </div>
          </div>
        </section>

        {/* Sessão 7: Agende sua sessão */}
        <section
          id="agende"
          className="min-h-screen w-full flex items-center bg-[#eeebe6] relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <AnimatedText className="text-2xl text-[#43645d]/80 mb-8">
                Você já entendeu que não dá mais pra viver no automático. Já percebeu que não precisa seguir um roteiro
                que não escreveu. Agora é hora de escolher a si mesma. De iniciar um processo que reconstrói, fortalece
                e resgata o que há de mais valioso: você.
              </AnimatedText>
              <AnimatedText className="text-2xl text-[#43645d]/80 mb-12" delay={0.3}>
                Agende sua sessão e comece essa reconexão com coragem e verdade.
              </AnimatedText>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="flex justify-center"
              >
                <AnimatedButton href="https://wa.link/mroli5" className="text-lg">
                  Quero agendar agora
                </AnimatedButton>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Sessão 8: Conheça nossa fundadora */}
        <section
          id="fundadora"
          className="min-h-screen w-full flex items-center gradient-bg-section text-white relative overflow-hidden py-20"
        >
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto">
              <SectionTitle className="text-white text-center mb-12">Conheça nossa fundadora</SectionTitle>

              <div className="grid md:grid-cols-2 gap-16 items-center mt-8">
                <div className="flex justify-center">
                  <div className="w-full max-w-md">
                    <ElegantImageFrame
                      src="https://i.imgur.com/bl1jGBd.jpeg"
                      alt="Psicóloga Lorena Braga"
                      delay={0.3}
                      variant="dark"
                      aspectRatio="3/4"
                    />
                  </div>
                </div>

                <div className="space-y-6 text-white/90">
                  <AnimatedText tag="h3" className="text-2xl text-white/90 mb-8 font-playfair italic">
                    Prazer, sou Lorena Braga
                  </AnimatedText>

                  <AnimatedText delay={0.3}>
                    Sou psicóloga clínica há mais de 15 anos. Me formei e fiz mestrado na UERJ, onde aprofundei meu
                    compromisso com a escuta, com o pensamento crítico e com a complexidade da vida humana.
                  </AnimatedText>

                  <AnimatedText delay={0.4}>
                    Escolhi a Fenomenologia Existencial como abordagem porque acredito que cada pessoa carrega uma
                    história única — com dores que não cabem em rótulos e movimentos que merecem ser compreendidos com
                    profundidade.
                  </AnimatedText>

                  <AnimatedText delay={0.5}>
                    Nos últimos anos, venho me dedicando especialmente a escutar mulheres que se sentem fora do roteiro
                    esperado: que não foram mães, não se casaram ou simplesmente não se reconhecem mais nos papéis que
                    ocupam. São dores silenciosas, muitas vezes escondidas atrás de conquistas e sorrisos.
                  </AnimatedText>

                  <AnimatedText delay={0.6}>
                    Meu propósito é criar um espaço onde essas histórias possam ser ditas, sentidas e ressignificadas —
                    com respeito, acolhimento e verdade.
                  </AnimatedText>

                  <AnimatedText delay={0.7}>
                    Sou movida por profundezas. E também por pausas. Entre um mergulho no mar e uma xícara de café com
                    um bom livro, reencontro o ritmo que levo pra clínica: presença, escuta e coragem.
                  </AnimatedText>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="bg-[#284146] py-12 text-white">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-6 md:mb-0">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-[#eeebe6] flex items-center justify-center">
                    <span className="text-[#43645d] font-playfair font-medium italic">LB</span>
                  </div>
                  <span className="text-white font-medium">Lorena Braga</span>
                </div>
              </div>
              <div className="flex flex-col md:flex-row items-center gap-6">
                <a
                  href="https://wa.link/mroli5"
                  className="text-white hover:text-[#5395a0] transition-colors duration-300"
                >
                  Agende sua sessão
                </a>
                <a
                  href="https://www.instagram.com/psicologa_lorena_braga/"
                  className="text-white hover:text-[#5395a0] transition-colors duration-300 flex items-center gap-2"
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
                  </svg>
                  Instagram
                </a>
              </div>
              <div className="text-center md:text-right mt-6 md:mt-0">
                <p className="text-white/80 text-sm">
                  © {new Date().getFullYear()} Lorena Braga Psicologia. Todos os direitos reservados.
                </p>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
